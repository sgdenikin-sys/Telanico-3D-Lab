# Settlements Hall V3 Lite

19,816 triangles, unchanged 11 PBR materials, four animation clips.
Blender: blender/generated/settlements_hall_lite/settlements_hall.blend
Godot model: godot/assets/generated/settlements_hall.glb
Open godot/project.godot with Godot 4.6.3. O opens, C closes, D plays demo.
Regenerate with --quality lite. See docs/assets/SETTLEMENTS_HALL_LITE.md.
This is an isolated viewer project. Original V2 and the game are untouched.
