# Telanico — Settlements Hall

Open `blender/generated/settlements_hall/settlements_hall.blend` in Blender.
The engine model is `godot/assets/generated/settlements_hall.glb`.
Open `godot/project.godot` in Godot 4.6.3 for the independent asset viewer.
This package contains no game or production-game modifications.

34,473 triangles; 11 material surfaces; 1 unit = 1 metre; Godot front +Z.
Seven editable architectural collections; original procedural geometry.

See `docs/assets/SETTLEMENTS_HALL.md` for regeneration, preserving hand edits,
materials, collisions and verification limits. Review images and reports are
in `blender/generated/settlements_hall/`.

The included project is a standalone inspection project, separate from the
repository game. Its main scene is the asset viewer. The live game was not
changed or deployed. Generated binaries are intentionally outside Git history.
