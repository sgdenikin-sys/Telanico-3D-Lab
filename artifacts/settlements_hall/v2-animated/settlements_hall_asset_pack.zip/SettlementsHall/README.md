# Settlements Hall — animated asset

Open blender/generated/settlements_hall/settlements_hall.blend in Blender.
The engine asset is godot/assets/generated/settlements_hall.glb.
Open godot/project.godot in Godot 4.6.3 for the independent viewer.
O opens, C closes, D plays the combined demonstration.

34,643 triangles, 11 PBR materials. Two independent hinges and four
morph-animated fabric pieces. 1 unit = 1 metre. Godot facing +Z.

See docs/assets/SETTLEMENTS_HALL.md for animation, editing and verification.
The ZIP viewer is a separate project; the existing game was not changed.
